package advJavaSecurity;

public class ApplicationRegistryTestClient {

	public static void main(String[] args) {
		ApplicationRegistry registry = new ApplicationRegistry();
		
		// Test basic capability of add and get
		String key = "appX.cacheSize";
		String value = "20";
		registry.addToRegistry(key,value,false);
		if (!registry.getFromRegistry(key).equals(value))
			System.err.println("TEST failed: " + key + "," + value);
		else
			System.out.println("TEST passed");
		
		// Test intentional overwrite
		key = "appX.logFileName";
		String firstValue = "/temp/logFile";
		String secondValue = "/temp/newLogFile";
		registry.addToRegistry(key,firstValue,false);
		registry.addToRegistry(key,secondValue,true);
		if (!registry.getFromRegistry(key).equals(secondValue))
			System.err.println("TEST failed: " + key + "," + secondValue);
		else
			System.out.println("TEST passed");
		
		// Test rejection of overwrite
		key = "appX.logRotationPolicy";
		firstValue = "size";
		secondValue = "date";
		registry.addToRegistry(key,firstValue,false);
		try {
			registry.addToRegistry(key,secondValue,false);
			//shouldn't get to next statement
			System.err.println("TEST failed: " + key + "," + secondValue);
		} catch (IllegalArgumentException ex) {
			if (registry.getFromRegistry(key).equals(firstValue))
				System.out.println("TEST passed");
			else
				System.err.println("TEST failed: " + key + "," + firstValue);
		}
		
			
				
	}

}
