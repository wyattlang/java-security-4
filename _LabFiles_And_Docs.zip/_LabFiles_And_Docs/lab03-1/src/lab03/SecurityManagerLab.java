package lab03;

import java.io.IOException;

//import java.lang.*;
	//	import java.util.Properties;
		 
		public class SecurityManagerLab
		{
		    public static void main(String[] args)
		    {
		        // Printing Name of the system property
		        //System.out.println("user.dir: "+System.getProperty("user.dir"));
		 
		        // Fetches the property set with 'home' key
		        //System.out.println("home: "+System.getProperty("home"));
		        // Resulting in Null as no property is present
		 
		        // Printing 'name of Operating System'
		        System.out.println("os.name: "+System.getProperty("os.name"));
		 
		        // Printing 'JAVA Runtime version'
		        //System.out.println("version: "+System.getProperty("java.runtime.version" ));
		 
		        // Printing 'name' property
		        //System.out.println("name: "+System.getProperty("name" ));
		        // Resulting in Null as no property is present
		        
		     // Printing 'JAVA version'
		        System.out.println("version: "+System.getProperty("java.version" ));
		        
		     // Printing 'JAVA user.home'
		        //System.out.println("version: "+System.getProperty("user.home" ));
		        
		     // Printing 'JAVA java.home'
		        //System.out.println("version: "+System.getProperty("java.home" ));
		        
		        try {
					java.net.ServerSocket ss = new java.net.ServerSocket(900);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		        
		    }
		}
	

