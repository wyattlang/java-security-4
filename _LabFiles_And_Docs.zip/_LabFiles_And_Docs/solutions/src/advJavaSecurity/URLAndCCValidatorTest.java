package advJavaSecurity;



import org.apache.commons.validator.routines.CreditCardValidator;
import org.apache.commons.validator.routines.EmailValidator;
import org.apache.commons.validator.routines.UrlValidator;

public class URLAndCCValidatorTest {
  public static void main(String args[]) {
	  
	  UrlValidator uv = UrlValidator.getInstance();
	  boolean b = uv.isValid(args[0]);
	  System.out.println(b);

	  CreditCardValidator ccv = new CreditCardValidator (CreditCardValidator.VISA);
	  b = ccv.isValid(args[0]);
	  System.out.println(b);
  }
}
