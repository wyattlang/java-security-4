package advJavaSecurity;

import java.util.HashMap;

// This class holds important application settings
public final class ApplicationRegistry {
  private HashMap<String, String> registry = new HashMap<String,String>();
  
  private ApplicationRegistry() {} // Empty no-arg constructor
  
  private static ApplicationRegistry applicationRegistry;  
  public static ApplicationRegistry getApplicationRegistry() {
	  if (applicationRegistry == null)
		  applicationRegistry = new ApplicationRegistry();
	  return applicationRegistry;
  }
  
  public void addToRegistry(String key, String value, boolean overwriteAllowed) 
  											throws IllegalArgumentException {
	  if (overwriteAllowed == false) {
		  // Throwing a custom checked Exception would be better, but
		  // this will be good enough for our purposes
		  if (registry.containsKey(key)) throw new IllegalArgumentException();
	  }
	  registry.put(key, value);
  }
  
  public String getFromRegistry (String key) {
	  return registry.get(key);
  }

}
