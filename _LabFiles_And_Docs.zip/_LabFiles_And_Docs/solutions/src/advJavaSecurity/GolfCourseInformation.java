// THIS FILE REMAINS UNCHANGED THROUGHOUT THE LAB
// NOTHING FOR THE STUDENT TO CHANGE
// On my machine, the correct argument for this lab was 
// "..\..\My Documents\passwords"

package advJavaSecurity;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;

public class GolfCourseInformation {

	public static void main(String[] args) throws IOException {
		if (args.length != 1) {
			System.out.println("You must supply the number of the golf hole! (1-18)");
			System.exit(0);
		}
		String fileName = args[0] + ".txt";

		Charset charset = Charset.forName("US-ASCII");
		File file = new File(fileName).getCanonicalFile();
		Path path = FileSystems.getDefault().getPath("", file.toString());
		try (BufferedReader reader = Files.newBufferedReader(path, charset);) {
			String line = null;
			while ((line = reader.readLine()) != null) {
				System.out.println(line);
			}
		} catch (IOException x) {
			System.err.format("IOException: %s%n", x);
		}

	}

}
