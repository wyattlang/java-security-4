package advJavaSecurity;

import org.apache.commons.validator.routines.EmailValidator;

public class EmailValidatorTestOne {
  public static void main(String args[]) {
	  EmailValidator ev = EmailValidator.getInstance();
	  boolean b = ev.isValid("hello@hello.com");
	  System.out.println(b);

	  b = ev.isValid("hello!hello.com");
	  System.out.println(b);
  }
}
