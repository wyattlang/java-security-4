package advJavaSecurity;

import org.apache.commons.validator.routines.EmailValidator;

public class EmailValidatorTestTwo {
  public static void main(String args[]) {
	  
	  for (String email : args) {
		  EmailValidator ev = EmailValidator.getInstance();
		  boolean b = ev.isValid(email);
		  System.out.println(b);
	  }
  }
}
