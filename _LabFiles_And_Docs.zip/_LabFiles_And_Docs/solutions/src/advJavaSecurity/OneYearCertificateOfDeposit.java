package advJavaSecurity;

import java.math.BigDecimal;
import java.util.Calendar;


public final class OneYearCertificateOfDeposit {

	final private Calendar maturationDate;
	final private BigDecimal amountToBePaidByBank;

	public OneYearCertificateOfDeposit(BigDecimal amountToBePaidByBank) {
		maturationDate = Calendar.getInstance();
		int currentYear = maturationDate.get(Calendar.YEAR);
		maturationDate.set(Calendar.YEAR, currentYear + 1);
		
		this.amountToBePaidByBank = amountToBePaidByBank;
		
	}

	public Calendar getMaturationDate() {
		// return maturationDate;  // DANGEROUS!
		return (Calendar) maturationDate.clone(); // could manually deep copy instead
	}
	
	public BigDecimal getAmountToBePaidByBank() {
		return this.amountToBePaidByBank;
	}
	
	@Override public String toString() {
		int year = maturationDate.get(Calendar.YEAR);
		int month = maturationDate.get(Calendar.MONTH) + 1; // Months are indexed to 0 not 1
		int day = maturationDate.get(Calendar.DAY_OF_MONTH);
		String date = month + "/" + day + "/" + year;
		return "CD will pay $" + amountToBePaidByBank + " on " + date;
	}
	
}
