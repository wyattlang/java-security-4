package lab01;

public class NPException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		if (args == null)
			System.out.println(args.length);

	}

}
