package advJavaSecurity;

import java.math.BigDecimal;
import java.util.Calendar;

public class OneYearCertificateOfDepositTestClient {

	public static void main(String[] args) {
		BigDecimal amountSet = new BigDecimal("24.45");
		//BigDecimal displayVal = modelVal.setScale(2, RoundingMode.HALF_EVEN)

		OneYearCertificateOfDeposit cd = new OneYearCertificateOfDeposit(amountSet);
		Calendar originalMaturationDate = cd.getMaturationDate();
		int originalYear = originalMaturationDate.get(Calendar.YEAR);
		int originalMonth = originalMaturationDate.get(Calendar.MONTH); 
		int originalDay = originalMaturationDate.get(Calendar.DAY_OF_MONTH);		
		System.out.println("Created CD:  " + cd);
						
		// ATTACK!
		Calendar tomorrow = Calendar.getInstance();
		int year = tomorrow.get(Calendar.YEAR);
		int month = tomorrow.get(Calendar.MONTH); 
		int day = tomorrow.get(Calendar.DAY_OF_MONTH) + 1; // set to tomorrow
		
		originalMaturationDate.set(Calendar.YEAR,year);
		originalMaturationDate.set(Calendar.MONTH,month);
		originalMaturationDate.set(Calendar.DAY_OF_MONTH,day);
		System.out.println("CD is now:  " + cd);
		
		Calendar maturationDateChangedPerhaps = cd.getMaturationDate();
		int newYearValue = maturationDateChangedPerhaps.get(Calendar.YEAR);
		int newMonthValue = maturationDateChangedPerhaps.get(Calendar.MONTH); 
		int newDayValue = maturationDateChangedPerhaps.get(Calendar.DAY_OF_MONTH);		
		System.out.println("CHECKING TO SEE IF DATE HAS CHANGED...");
		if (newYearValue != originalYear || newMonthValue != originalMonth || newDayValue != originalDay) {
		  System.err.println("MATURATION DATE HAS BEEN HACKED!!!");
		} else {
			System.out.println("TEST PASSED!  HACK AVOIDED");
		}
	}

}
