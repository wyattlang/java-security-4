Use the stepes in the lab instructions and the files from the solutions folder:
     EmailValidatorTestOne.java 
     EmailValidatorTestTwo.java
     URLAndCCValidatorTest.java